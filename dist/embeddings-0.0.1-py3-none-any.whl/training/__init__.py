"""
# Training

Submodules containing a simple cli wrapper for gensim's implementation of word2vec. 
"""
