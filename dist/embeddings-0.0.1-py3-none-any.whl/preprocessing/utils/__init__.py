"""
# Utils
Different utils functions for the preprocessor class.
"""
